//
//  ULSmoothContainerView.h
//  KilaKit
//
//  Created by 方世峰 on 2021/5/11.
//  Copyright © 2021 LeeWong. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ULSmoothContainerView;

NS_ASSUME_NONNULL_BEGIN

@protocol ULSmoothContainerViewDelegate <NSObject>

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView collectViewDidScroll:(UIScrollView *)scrollView;

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView collectViewDidScroll:(UIScrollView *)scrollView toIndex:(NSInteger)index;

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView scrollViewDidEndDecelerating:(UIScrollView *)scrollView;

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView;

@end

@interface ULSmoothContainerView : UIView

///当前底部containerCollectView的Index
@property (nonatomic, assign) NSInteger currentListIndex;

@property (nonatomic, weak) id <ULSmoothContainerViewDelegate>delegate;
/// 初始化底部container的segment + collectView所包含的listscrollview
/// @param segmentView segmentView
/// @param listDict 底部collectView需要容纳的listScrollview集合
- (void)setupContainerSegmentView:(UIView *)segmentView listView:(NSDictionary *)listDict topMargin:(CGFloat)margin;

- (void)disableContentScroll;

- (void)enableContentScroll;

- (void)forbidContentScroll;

- (void)resetAllContentScrollViewOffSet;

/// 滚动底部collectView到指定index
/// @param index index
/// @param animation animation
- (void)scrollContainerToIndex:(NSInteger)index animation:(BOOL)animation;
/// 滚动底部当前内容listScrollview到指定Offset
/// @param offset offset
- (void)updateContainerListScrollOffset:(CGPoint)offset;
/// 返回当前index下的listScrollView
- (UIScrollView *)getCurrentListScrollView;

// 屏幕旋转刷新UI
- (void)refreshUIForRotationWithContainerSize:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
