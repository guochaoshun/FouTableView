//
//  ULSmoothContainnerListViewDelegate.h
//  KilaKit
//
//  Created by 方世峰 on 2021/5/17.
//  Copyright © 2021 LeeWong. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef ULSmoothContainnerListViewDelegate_h
#define ULSmoothContainnerListViewDelegate_h

@protocol ULSmoothContainnerListViewDelegate <NSObject>

/// 返回listView，如果是vc就返回vc.view,如果是自定义view，就返回view本身
- (UIView *)listView;

/// 返回vc或view内部持有的UIScrollView或UITableView或UICollectionView
- (UIScrollView *)listScrollView;
/// 返回vc或view内部持有的UIScrollView或UITableView或UICollectionView的内容总高度
- (CGFloat)listScrollViewContentHeight;

@end

#endif /* ULSmoothContainnerListViewDelegate_h */
