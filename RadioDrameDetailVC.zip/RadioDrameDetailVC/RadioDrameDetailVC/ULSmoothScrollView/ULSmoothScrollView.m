//
//  ULSmoothScrollView.m
//  KilaKit
//
//  Created by 方世峰 on 2021/5/14.
//  Copyright © 2021 LeeWong. All rights reserved.
//

#import "ULSmoothScrollView.h"
#import "ULSmoothTopScrollView.h"
#import "ULSmoothContainerView.h"
#import "UIView+UL.h"

@interface ULSmoothScrollView ()<UIScrollViewDelegate, UIGestureRecognizerDelegate, ULSmoothContainerViewDelegate>

@property (nonatomic, strong) NSMutableDictionary *listDict;
@property (nonatomic, weak) UIView *headView;
@property (nonatomic, weak) UIView *segmentedView;
/// 头部视图, 上面有ULRadioDramaDetailView, 把一个TableView完全展开显示
@property (nonatomic,strong) UIScrollView *bottomScrollView;
@property (nonatomic, strong) ULSmoothContainerView *tableContainer;

@property (nonatomic, strong) ULSmoothTopScrollView *topScrollView;
@property (nonatomic, strong) UIView *containerView;

@property (nonatomic, strong) UIPanGestureRecognizer *panGesTureForTableContainer;

@property (nonatomic, assign) CGFloat lastTableContainerTransitionY;
@property (nonatomic, assign) BOOL isDragContentScrollView;
@property (nonatomic, assign) BOOL isOnTop;

@end

@implementation ULSmoothScrollView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupData];
    }
    return self;
}

- (void)setupData {
    self.listDict = [[NSMutableDictionary alloc] init];
    self.ceilPointHeight = 0;
    self.bottomMargin = 0;
    self.defaultSelectedIndex = 0;
}

- (void)setupViews {
    [self addSubview:self.containerView];

    [self.containerView addSubview:self.bottomScrollView];
    [self.containerView addSubview:self.tableContainer];

    // 拖动手势
    self.panGesTureForTableContainer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleTableContainerPan:)];
    [self.tableContainer addGestureRecognizer:self.panGesTureForTableContainer];

    self.panGesTureForTableContainer.delegate = self;

    // 层级最上层的视图, 透传滑动事件到不同的ScrollView处理
    [self addSubview:self.topScrollView];
    // topScrollView 的手势传递给 self.containerView,
    // 同一个手势只能加在一个view上, 所以topScrollView的拖动手势没了, 加在了containerView上
    [self.containerView addGestureRecognizer:self.topScrollView.panGestureRecognizer];

    self.containerView.frame = self.bounds;
    self.bottomScrollView.frame = CGRectMake(0, 0, self.ul_width, self.ul_height - self.bottomMargin);
    self.tableContainer.frame = CGRectMake(0, self.ul_height - self.bottomMargin, self.ul_width, self.ul_height - self.ceilPointHeight);
    [self.tableContainer ul_bezierPathTopCornerWithCornerRadii:9.f];
    self.topScrollView.frame = self.bounds;
    NSLog(@"containerView:%@,\nbottomScrollView:%@",self.containerView, self.bottomScrollView);

}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.topScrollView ) {
        if ([self.delegate respondsToSelector:@selector(smoothView:listScrollViewDidScroll:contentOffset:)]) {
            [self.delegate smoothView:self listScrollViewDidScroll:scrollView contentOffset:scrollView.contentOffset];
        }

        //头部scrollview可滚动的最大距离、头部滚动完之后底部的scrollview需要接着滚动
        CGFloat maxYOfBottomScrollView = self.bottomScrollView.contentSize.height - self.bottomScrollView.ul_height;

        if (scrollView.contentOffset.y <= maxYOfBottomScrollView) {
            NSLog(@"bottom %f-----%f",scrollView.contentOffset.y, maxYOfBottomScrollView);
            //当头部滚动时bounds保持不动、即底部视图在露出的状态
            self.containerView.bounds = self.bounds;
            //将offset值传给头部视图让其滚动
            self.bottomScrollView.contentOffset = scrollView.contentOffset;
            //当头部滚动时bounds保持不动，这个状态下底部视图的pan手势才可响应，当头部视图滚动完毕时底部视图的滚动效果是根据bounds origin的y值来确定的
            self.panGesTureForTableContainer.enabled = YES;
            [self.tableContainer resetAllContentScrollViewOffSet];
            self.hoverType = ULSmoothScrollViewHoverTypeBottom;
            
        } else if (scrollView.contentOffset.y > maxYOfBottomScrollView && scrollView.contentOffset.y <= (maxYOfBottomScrollView + [self getContainerTopMargin])) {
            CGRect scrolledBoundsForContainerView = self.containerView.bounds;

            NSLog(@"middle ------%f-----%f",scrollView.contentOffset.y, maxYOfBottomScrollView);
            //头部视图滚动完毕，故将其固定在指定的contentOffset
            self.bottomScrollView.contentOffset = CGPointMake(0, maxYOfBottomScrollView);
            //这时候contentOffset是超出头部视图可滚动范围，将这个差值赋值给bounds使整体视图向上滚动，产生底部视图滚动效果
            scrolledBoundsForContainerView.origin.y = scrollView.contentOffset.y - maxYOfBottomScrollView;
            self.containerView.bounds = scrolledBoundsForContainerView;

            NSLog(@"self.containerView.bounds %f",scrolledBoundsForContainerView.origin.y);

            [self.tableContainer resetAllContentScrollViewOffSet];
            self.panGesTureForTableContainer.enabled = NO;
            self.hoverType = ULSmoothScrollViewHoverTypeMiddle;
        } else {
            NSLog(@"top ------%f-----%f",scrollView.contentOffset.y, maxYOfBottomScrollView);

            CGRect scrolledBoundsForContainerView = self.containerView.bounds;
            //计算出底部视图可实现置顶效果的最大origin y值，将其赋值给bounds，这时bounds固定实现实现置顶效果
            scrolledBoundsForContainerView.origin.y = [self getContainerTopMargin];
            self.containerView.bounds = scrolledBoundsForContainerView;

            //这时候contentOffset是超出头部视图可滚动范围 + 底部视图可置顶滚动范围，将这个差值赋值给底部的内容视图，实现滚动效果（选集列表可滑动、评论列表可滑动）
            [self.tableContainer updateContainerListScrollOffset:CGPointMake(0, scrollView.contentOffset.y - (maxYOfBottomScrollView + [self getContainerTopMargin]))];

            self.panGesTureForTableContainer.enabled = NO;
            self.hoverType = ULSmoothScrollViewHoverTypeTop;
            NSLog(@"self.containerView.bounds %f",scrolledBoundsForContainerView.origin.y);

        }
    }
}

- (void)handleTableContainerPan:(UIPanGestureRecognizer *)pan {
    CGPoint translation = [pan translationInView:self.tableContainer];
    NSLog(@"handleTableContainerPan:%f", translation.y);
    if (pan.state == UIGestureRecognizerStateBegan) {
        NSLog(@"UIGestureRecognizerStateBegan");
        if ([self.delegate respondsToSelector:@selector(smoothViewDragBegan:)]) {
            [self.delegate smoothViewDragBegan:self];
        }

        // 判断当前是拖拽方向,当container跟随手势开始向下滑动时，调用此代理隐藏navigation
        // 往上拖动, translation.y 为正
        // 往下拖动, translation.y 为负
        if (translation.y > 0) {
            // 向下拖拽
            if (self.isDragContentScrollView == NO) {
                if ([self.delegate respondsToSelector:@selector(smoothViewBeganDragDismiss:)]) {
                    [self.delegate smoothViewBeganDragDismiss:self];
                }
            } else {
                if ([self.tableContainer getCurrentListScrollView].contentOffset.y <= 0) {
                    if ([self.delegate respondsToSelector:@selector(smoothViewBeganDragDismiss:)]) {
                        [self.delegate smoothViewBeganDragDismiss:self];
                    }
                }
            }
        }
    }

    if (self.isDragContentScrollView) {//手势发生在底部内容视图
        NSLog(@"currentScrollView.contentOffset.y:%f", [self.tableContainer getCurrentListScrollView].contentOffset.y);
        if ([self.tableContainer getCurrentListScrollView].contentOffset.y <= 0) {//内容视图滚动到头部，下次再触发下滑手势时底部整体视图需要向下移动故将self.isDragContentScrollView = NO
            if (translation.y > 0) { // 向下拖拽
                self.isDragContentScrollView = NO;
                CGRect frame = self.tableContainer.frame;
                frame.origin.y += translation.y;
                self.tableContainer.frame = frame;
                //使内容视图的固定在offsetZero位置，这个位置的判断会调用多次如果设置为scrollenable No会出现内容视图不可滚动的情况
                [self.tableContainer forbidContentScroll];
            }
        }
    } else {
        if ([self.tableContainer getCurrentListScrollView].contentOffset.y <= 0) {
            //这个状态下降内容视图scrollenable为No，只响应pan手势，使下滑手势内容视图禁止滚动，不会出现抖动情况
            [self.tableContainer disableContentScroll];
        }
        if (translation.y > 0 ) {// 向下拖拽
            CGRect frame = self.tableContainer.frame;
            frame.origin.y += translation.y;
            if (frame.origin.y >= [self getContainerTopMargin]) {
                //在手势拖动的到达底部临界，固定底部视图，实现置底效果
                frame.origin.y = [self getContainerTopMargin];
                self.hoverType = ULSmoothScrollViewHoverTypeBottom;
                [self.tableContainer disableContentScroll];
            }

            self.tableContainer.frame = frame;
        }else if (translation.y < 0) { // 向上拖拽
            CGRect frame = self.tableContainer.frame;
            frame.origin.y += translation.y;
            if (frame.origin.y <= self.ceilPointHeight) {
                //在手势拖动的到达顶部临界，固定底部视图，实现置顶效果
                frame.origin.y = self.ceilPointHeight;
                self.isOnTop = YES;
            }
            self.tableContainer.frame = frame;
        }
    }
    if (pan.state == UIGestureRecognizerStateEnded) {
        //手势结束时，根据偏移量计算是否是置顶or置底
        CGPoint velocity = [pan velocityInView:self.tableContainer];
        if (velocity.y < 0) { // 上滑
            if (fabs(self.lastTableContainerTransitionY) > 5 && self.isDragContentScrollView == NO) {
                [self dragShow];
            } else {//手势一直跟随上下滑动，进行手势释放情况
                if (self.tableContainer.frame.origin.y > self.tableContainer.frame.size.height / 2) {
                    [self dragDismiss];
                }else {
                    [self dragShow];
                }
            }
        } else { //下滑
            if (fabs(self.lastTableContainerTransitionY) > 5 && self.isDragContentScrollView == NO) {
                [self dragDismiss];
            } else {//手势一直跟随上下滑动，进行手势释放情况
                if (self.tableContainer.frame.origin.y > self.tableContainer.frame.size.height / 2) {
                    [self dragDismiss];
                } else {
                    [self dragShow];
                }
            }
        }
        self.isDragContentScrollView = NO;
    }

    [pan setTranslation:CGPointZero inView:self.tableContainer];
    self.lastTableContainerTransitionY = translation.y;
}

#pragma mark - Public
- (void)reloadData {
    self.currentIndex = self.defaultSelectedIndex;
    if (self.dataSource && [self.dataSource respondsToSelector:@selector(headerViewInSmoothView:)] && [self.dataSource respondsToSelector:@selector(segmentedViewInSmoothView:)]) {
        self.headView = [self.dataSource headerViewInSmoothView:self];
        self.segmentedView = [self.dataSource segmentedViewInSmoothView:self];

        [self.bottomScrollView addSubview:self.headView];
        self.bottomScrollView.contentSize = CGSizeMake(self.ul_width, self.headView.ul_height);

        [self reloadListDictData];
        [self.tableContainer disableContentScroll];

        //头部内容高度 + 底部视图内容高度 + 底部segment高度
        [self.topScrollView setContentSize:CGSizeMake(0, self.headView.ul_height + [[self getCurrentList] listScrollViewContentHeight] + self.segmentedView.ul_height)];
        self.hoverType = ULSmoothScrollViewHoverTypeBottom;
    }

    if (!self.isOnTop) {
        if ([self.delegate respondsToSelector:@selector(smoothViewAfterInitSetScrollViewOffsetAndInset:)]) {
            [self.delegate smoothViewAfterInitSetScrollViewOffsetAndInset:self];
        }
    }
}

- (void)scrollHorizentalToIndex:(NSInteger)index animation:(BOOL)animation {
    [self.tableContainer scrollContainerToIndex:index animation:animation];
    self.currentIndex = index;
    [self updateTopScrollView];
}

- (void)showingOnTop {
    if (self.hoverType == ULSmoothScrollViewHoverTypeBottom) {
        [self dragShow];
        if ([self.delegate respondsToSelector:@selector(smoothViewDragOnTapSegment:)]) {
            [self.delegate smoothViewDragOnTapSegment:self];
        }
    }
}

- (id<ULSmoothContainnerListViewDelegate>)getCurrentList {
    return self.listDict[@(self.currentIndex)];
}

- (UIScrollView *)getTopScrollView {
    return self.topScrollView;
}

- (CGFloat)getTopScrollViewContentOffectY {
    return self.topScrollView.contentOffset.y;
}

- (void)refreshTopScrollViewContentHeight {
    CGFloat headViewContentHeight = self.headView.ul_height;
    CGSize size = self.bottomScrollView.contentSize;
    size.height = headViewContentHeight;
    self.bottomScrollView.contentSize = size;
    CGFloat contentHeight = [[self getCurrentList] listScrollViewContentHeight];
    //防止topscrollview走代理scrollViewdidscroll方法
    self.topScrollView.delegate = nil;
    [self.topScrollView setContentSize:CGSizeMake(0, self.headView.ul_height + contentHeight + self.segmentedView.ul_height)];
    self.topScrollView.delegate = self;
}

- (void)refreshHeaderSegemntAndListDict {
    self.currentIndex = 0;
    [self reloadListDictData];
    [self.tableContainer scrollContainerToIndex:self.currentIndex animation:NO];
    //头部内容高度 + 底部视图内容高度 + 底部segment高度
    [self updateTopScrollViewContentSizeAndContentOffsetIsHandle:NO];
    if (!self.isOnTop) {
        if ([self.delegate respondsToSelector:@selector(smoothViewAfterInitSetScrollViewOffsetAndInset:)]) {
            [self.delegate smoothViewAfterInitSetScrollViewOffsetAndInset:self];
        }
    }
}

- (void)reloadListDictData {
    [_listDict removeAllObjects];
    NSInteger count = 0;
    if (self.dataSource && [self.dataSource respondsToSelector:@selector(numberOfListsInSmoothView:)]) {
        count = [self.dataSource numberOfListsInSmoothView:self];
    }

    for (NSInteger index = 0; index < count; index++) {
        id<ULSmoothContainnerListViewDelegate> list = self.listDict[@(index)];
        if (list == nil) {
            if (self.dataSource && [self.dataSource respondsToSelector:@selector(smoothView:initListAtIndex:)]) {
                list = [self.dataSource smoothView:self initListAtIndex:index];
                _listDict[@(index)] = list;
            }
        }

        UIScrollView *listScrollView = list.listScrollView;
        if ([listScrollView isKindOfClass:[UITableView class]]) {
            ((UITableView *)listScrollView).estimatedRowHeight = 0;
            ((UITableView *)listScrollView).estimatedSectionHeaderHeight = 0;
            ((UITableView *)listScrollView).estimatedSectionFooterHeight = 0;
        }

        if (@available(iOS 11.0, *)) {
            listScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        [listScrollView setContentOffset:CGPointZero animated:NO];
    }

    [self.tableContainer setupContainerSegmentView:self.segmentedView listView:_listDict topMargin:self.segmentedView.ul_height];
}

- (void)dragDismissWithoutAnimation {
    if ([self.delegate respondsToSelector:@selector(smoothViewDragDismiss:)]) {
        [self.delegate smoothViewDragDismiss:self];
    }
    self.isOnTop = NO;
    CGRect frame = self.tableContainer.frame;
    frame.origin.y = self.ul_height - self.bottomMargin;
    self.tableContainer.frame = frame;
    self.hoverType = ULSmoothScrollViewHoverTypeBottom;
    self.topScrollView.scrollEnabled = YES;
    [self.tableContainer disableContentScroll];
}

- (void)scrollToOriginalPoint {
    [self.topScrollView setContentOffset:CGPointZero animated:YES];
}

- (void)refreshUIForRotationWithFrame:(CGRect)frame bottomMargin:(CGFloat)bottomMargin {
    self.frame = frame;
    self.bottomMargin = bottomMargin;
    self.containerView.frame = self.bounds;
    self.bottomScrollView.frame = CGRectMake(0, 0, self.ul_width, self.ul_height - self.bottomMargin);
    // 底部选集、评论、周边
    [self.tableContainer refreshUIForRotationWithContainerSize:frame.size];
    // top scrollview
    self.topScrollView.frame = self.bounds;
    [self updateTopScrollViewContentSizeAndContentOffsetIsHandle:NO];
    [self scrollViewDidScroll:self.topScrollView];
}

#pragma mark - Private
///获取container的离顶部最大间距
- (CGFloat)getContainerTopMargin {
    return self.ul_height - self.ceilPointHeight - self.bottomMargin;
}

- (void)dragShow {
    if ([self.delegate respondsToSelector:@selector(smoothViewDragShowing:)]) {
        [self.delegate smoothViewDragShowing:self];
    }
    self.isOnTop = YES;
    [UIView animateWithDuration:0.25 animations:^{
        CGRect frame = self.tableContainer.frame;
        frame.origin.y = self.ceilPointHeight;
        self.tableContainer.frame = frame;
    } completion:^(BOOL finished) {
        if ([self.delegate respondsToSelector:@selector(smoothViewDragEnded:isOnTop:)]) {
            [self.delegate smoothViewDragEnded:self isOnTop:self.isOnTop];
        }
    }];
    self.topScrollView.scrollEnabled = NO;
    [self.tableContainer enableContentScroll];
}

- (void)dragDismiss {
    if ([self.delegate respondsToSelector:@selector(smoothViewDragDismiss:)]) {
        [self.delegate smoothViewDragDismiss:self];
    }
    self.isOnTop = NO;
    [UIView animateWithDuration:0.25 animations:^{
        CGRect frame = self.tableContainer.frame;
        frame.origin.y = self.ul_height - self.bottomMargin;
        self.tableContainer.frame = frame;
    } completion:^(BOOL finished) {
        if ([self.delegate respondsToSelector:@selector(smoothViewDragEnded:isOnTop:)]) {
            [self.delegate smoothViewDragEnded:self isOnTop:self.isOnTop];
        }
    }];
    self.hoverType = ULSmoothScrollViewHoverTypeBottom;
    self.topScrollView.scrollEnabled = YES;
    [self.tableContainer disableContentScroll];
}
/**
 数据改变时更新topScrollview
 @param isHandle 是否是手势或点击事件调用方法（切季时更新，不是手势触发所以isHandle为No）
 */
- (void)updateTopScrollViewContentSizeAndContentOffsetIsHandle:(BOOL)isHandle {
    CGFloat headViewContentHeight = self.headView.ul_height;
    CGSize size = self.bottomScrollView.contentSize;
    size.height = headViewContentHeight;
    self.bottomScrollView.contentSize = size;
    //切季时，有广告位bottomMargin会更新，相应self.bottomScrollView.frame需要更新
    CGRect frame = self.bottomScrollView.frame;
    frame.size.height = self.ul_height - self.bottomMargin;
    self.bottomScrollView.frame = frame;

    CGFloat contentHeight = [[self getCurrentList] listScrollViewContentHeight];
    //防止topscrollview走代理scrollViewdidscroll方法
    self.topScrollView.delegate = nil;
    [self.topScrollView setContentSize:CGSizeMake(0, self.headView.ul_height + contentHeight + self.segmentedView.ul_height)];

    CGRect scrolledBoundsForContainerView = self.containerView.bounds;

    if (self.hoverType == ULSmoothScrollViewHoverTypeMiddle) {
        //ULSmoothScrollViewHoverTypeMiddle代表头部视图已滚动完毕、将其offset置为最大
        CGFloat maxYOfBottomScrollView = self.bottomScrollView.contentSize.height - self.bottomScrollView.ul_height;
        [self.bottomScrollView setContentOffset:CGPointMake(0, maxYOfBottomScrollView) animated:NO];
        //ULSmoothScrollViewHoverTypeMiddle底部视图的offset为0，所以不需要更新，只更新TopScrollview的offset，再次触发scrollviewDidScroll时更新bounds的origin y值
        [self.topScrollView setContentOffset:CGPointMake(0, scrolledBoundsForContainerView.origin.y + maxYOfBottomScrollView) animated:NO];
        if (!isHandle) {
            //在切换季，有广告位bottomMargin会改变，需要重新计算frame及bounds
            CGRect tableFrame = self.tableContainer.frame;
            tableFrame.origin.y = self.ul_height - self.bottomMargin;
            self.tableContainer.frame = tableFrame;
            CGRect scrolledBoundsForContainerView = self.containerView.bounds;
            scrolledBoundsForContainerView.origin.y = self.topScrollView.contentOffset.y - maxYOfBottomScrollView;
            self.containerView.bounds = scrolledBoundsForContainerView;
        }
    } else if (self.hoverType == ULSmoothScrollViewHoverTypeTop){
        CGFloat maxYOfBottomScrollView = self.bottomScrollView.contentSize.height - self.bottomScrollView.ul_height;
        //当hoverType为ULSmoothScrollViewHoverTypeTop 说明bottomScrollView已经到最大offset
        [self.bottomScrollView setContentOffset:CGPointMake(0, maxYOfBottomScrollView) animated:NO];

        CGFloat topScrollOffsetY = maxYOfBottomScrollView + [self getContainerTopMargin];
        if (isHandle) {//区分切换季与切换segment或刷新头部视图时，对于TopScrollview的offset的赋值
            UIScrollView *currentListScrollView = [self.tableContainer getCurrentListScrollView];
            if (currentListScrollView.contentOffset.y > 0) {
                topScrollOffsetY += currentListScrollView.contentOffset.y;
            }
        } else {
            //在切换季，有广告位bottomMargin会改变，需要重新计算frame及bounds
            CGRect tableFrame = self.tableContainer.frame;
            tableFrame.origin.y = self.ul_height - self.bottomMargin;
            self.tableContainer.frame = tableFrame;
            CGRect scrolledBoundsForContainerView = self.containerView.bounds;
            //计算出底部视图可实现置顶效果的最大origin y值，将其赋值给bounds，这时bounds固定实现实现置顶效果
            scrolledBoundsForContainerView.origin.y = [self getContainerTopMargin];
            self.containerView.bounds = scrolledBoundsForContainerView;
        }
        [self.topScrollView setContentOffset:CGPointMake(0, topScrollOffsetY) animated:NO];
    } else {
        NSLog(@"hoverType == ULSmoothScrollViewHoverTypeBottom 当处于置底时，切换segment时会手动置顶");
        if (!isHandle) {//切换季时self.bottomMargin底部间距有可能会变化（如广播剧头部高度不足）这时需要重新计算tableContainer露出高度
            if (!self.isOnTop) {
                CGRect frame = self.tableContainer.frame;
                frame.origin.y = self.ul_height - self.bottomMargin;
                self.tableContainer.frame = frame;
                self.topScrollView.scrollEnabled = YES;
                [self.tableContainer disableContentScroll];
            } else {
                //切换季时 底部视图已通过抽屉收拾置顶，不需要重新计算tableContainer露出高度
                NSLog(@"切换季时 底部视图已通过手势置顶，不需要重新计算tableContainer露出高度");
            }
        }
    }
    self.topScrollView.delegate = self;
}

///切换segment index时更新
- (void)updateTopScrollView {
    //切换segment tab是需要调整topscrllview的contentSize contentOffset
    [self updateTopScrollViewContentSizeAndContentOffsetIsHandle:YES];
    if (self.isOnTop) {
        //使用手势置顶的情况下点击segment切换、也会触发 - (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch，这里会导致disableContentScroll，需要调用enableContentScroll使listscrollview可以继续滚动
        [self.tableContainer enableContentScroll];
    }
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if (gestureRecognizer == self.panGesTureForTableContainer) {
        //头部视图滚动的同时，只要底部视图没有跟随滚动，pan手势就会响应；当pan手势响应时将TopScrollview的进行固定，解决scrollviewDidScroll与pan手势回调有可能产生冲突的问题
        if (self.topScrollView.isDecelerating) {
            [self.topScrollView setContentOffset:self.topScrollView.contentOffset animated:NO];
        }
        //在底部视图通过手势在指定状态，这时候滚动内容视图，同时通过在segment区域通过下拉手势试图将底部视图隐藏；这时将内容视图滚动停止，解决scrollviewDidScroll与pan手势回调有可能产生冲突的问题
        if ([self.tableContainer getCurrentListScrollView].isDecelerating) {
            [[self.tableContainer getCurrentListScrollView] setContentOffset:[self.tableContainer getCurrentListScrollView].contentOffset animated:NO];
        }

        if (self.isOnTop) {
            UIView *touchView = touch.view;
            while (touchView != nil) {
                if (touchView == [self.tableContainer getCurrentListScrollView]) {
                    //在指定情况，如果手势在内容视图里，使tablview或collectview正常实现滚动
                    self.isDragContentScrollView = YES;
                    [self.tableContainer enableContentScroll];
                    break;
                }else if (touchView == self.tableContainer) {
                    //在指定情况，如果手势在segment视图里，使tablview或collectview停止滚动
                    self.isDragContentScrollView = NO;
                    [self.tableContainer disableContentScroll];
                    break;
                }
                touchView = (UIView *)[touchView nextResponder];
            }
        }
    }
    return YES;
}

- (BOOL)gestureRecognizer:(UIPanGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    if (gestureRecognizer == self.panGesTureForTableContainer) {
        if (otherGestureRecognizer == [self.tableContainer getCurrentListScrollView].panGestureRecognizer) {
            return YES;
        }
    }
    return NO;
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (scrollView == self.topScrollView) {
        if (!decelerate) {
            BOOL dragToDragStop = scrollView.tracking && !scrollView.dragging && !scrollView.decelerating;
            if (dragToDragStop) {
                [self smoothScrollerScrollViewDidEndScroll];
            }
        }
    }
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.topScrollView) {
        BOOL scrollToScrollStop = !scrollView.tracking && !scrollView.dragging && !scrollView.decelerating;
        if (scrollToScrollStop) {
            [self smoothScrollerScrollViewDidEndScroll];
        }
    }
}

- (void)smoothScrollerScrollViewDidEndScroll {
    if ([self.delegate respondsToSelector:@selector(smoothViewDidEndDecelerating:)]) {
        [self.delegate smoothViewDidEndDecelerating:self];
    }
}
#pragma mark - ULSmoothContainerViewDelegate

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView collectViewDidScroll:(UIScrollView *)scrollView {
    if ([self.delegate respondsToSelector:@selector(smoothView:scrollViewDidScroll:)]) {
        [self.delegate smoothView:self scrollViewDidScroll:scrollView];
    }
}

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView collectViewDidScroll:(UIScrollView *)scrollView toIndex:(NSInteger)index {
    self.currentIndex = index;
    [self updateTopScrollView];
    if ([self.delegate respondsToSelector:@selector(smoothView:scrollViewDidScroll:toIndex:)]) {
        [self.delegate smoothView:self scrollViewDidScroll:scrollView toIndex:index];
    }
}

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if ([self.delegate respondsToSelector:@selector(smoothView:scrollViewDidEndDecelerating:)]) {
        [self.delegate smoothView:self scrollViewDidEndDecelerating:scrollView];
    }
}

- (void)ulSmoothContainerView:(ULSmoothContainerView *)smoothView scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    if ([self.delegate respondsToSelector:@selector(smoothView:scrollViewDidEndScrollingAnimation:)]) {
        [self.delegate smoothView:self scrollViewDidEndScrollingAnimation:scrollView];
    }
}

#pragma mark - Initialize
- (UIView *)containerView {
    if (!_containerView) {
        _containerView = [[UIView alloc] initWithFrame:CGRectZero];
//        _containerView.backgroundColor = [UIColor yellowColor];
    }
    return _containerView;
}

- (UIScrollView *)bottomScrollView {
    if (!_bottomScrollView) {
        _bottomScrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
        _bottomScrollView.scrollEnabled = NO;
        if (@available(iOS 11.0, *)) {
            _bottomScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
    }
    return _bottomScrollView;
}

- (ULSmoothTopScrollView *)topScrollView {
    if (!_topScrollView) {
        _topScrollView = [[ULSmoothTopScrollView alloc] initWithFrame:CGRectZero];
        _topScrollView.showsVerticalScrollIndicator = NO;
        _topScrollView.showsHorizontalScrollIndicator = NO;
        if (@available(iOS 11.0, *)) {
            _topScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        _topScrollView.delegate = self;
    }
    return _topScrollView;
}

- (ULSmoothContainerView *)tableContainer {
    if (!_tableContainer) {
        _tableContainer = [[ULSmoothContainerView alloc] initWithFrame:CGRectZero];
        _tableContainer.backgroundColor = [UIColor whiteColor];
        _tableContainer.delegate = self;
    }
    return _tableContainer;
}

@end
