//
//  ULSmoothScrollView.h
//  KilaKit
//
//  Created by 方世峰 on 2021/5/14.
//  Copyright © 2021 LeeWong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ULSmoothContainnerListViewDelegate.h"

@class ULSmoothScrollView;
NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, ULSmoothScrollViewHoverType) {
    ULSmoothScrollViewHoverTypeTop,
    ULSmoothScrollViewHoverTypeMiddle,
    ULSmoothScrollViewHoverTypeBottom,
};

@protocol ULSmoothScrollViewDataSource <NSObject>

@required
/// 返回页面的headerView视图
/// @param smoothView smoothView
- (UIView *)headerViewInSmoothView:(ULSmoothScrollView *)smoothView;

/// 返回需要悬浮的分段视图
/// @param smoothView smoothView
- (UIView *)segmentedViewInSmoothView:(ULSmoothScrollView *)smoothView;

/// 返回列表个数
/// @param smoothView smoothView
- (NSInteger)numberOfListsInSmoothView:(ULSmoothScrollView *)smoothView;

/// 根据index初始化一个列表实例
/// @param smoothView smoothView
/// @param index 列表索引
- (id <ULSmoothContainnerListViewDelegate>)smoothView:(ULSmoothScrollView *)smoothView initListAtIndex:(NSInteger)index;

@end

@protocol ULSmoothScrollViewDelegate <NSObject>
@optional
/// 列表容器滑动代理
/// @param smoothView smoothView
/// @param scrollView containerScrollView
- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidScroll:(UIScrollView *)scrollView;

/// 列表容器滑动代理
/// @param smoothView smoothView
/// @param scrollView containerScrollView
/// @param index index
- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidScroll:(UIScrollView *)scrollView toIndex:(NSInteger)index;

/// 当前列表滑动代理
/// @param smoothView smoothView
/// @param scrollView 当前的列表scrollView
/// @param contentOffset 转换后的contentOffset
- (void)smoothView:(ULSmoothScrollView *)smoothView listScrollViewDidScroll:(UIScrollView *)scrollView contentOffset:(CGPoint)contentOffset;


- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidEndDecelerating:(UIScrollView *)scrollView;


- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView;

/// 开始拖拽代理
/// @param smoothView smoothView
- (void)smoothViewDragBegan:(ULSmoothScrollView *)smoothView;

/// 结束拖拽代理
/// @param smoothView smoothView
/// @param isOnTop 是否通过拖拽滑动到顶部
- (void)smoothViewDragEnded:(ULSmoothScrollView *)smoothView isOnTop:(BOOL)isOnTop;

- (void)smoothViewDragDismiss:(ULSmoothScrollView *)smoothView;
- (void)smoothViewDragShowing:(ULSmoothScrollView *)smoothView;
- (void)smoothViewBeganDragDismiss:(ULSmoothScrollView *)smoothView;

- (void)smoothViewDragOnTapSegment:(ULSmoothScrollView *)smoothView;

- (void)smoothViewHeaderViewDidMoveToBackWhenScrolling:(ULSmoothScrollView *)smoothView;
- (void)smoothViewHeaderViewDidMoveToHeaderViewWhenScrolling:(ULSmoothScrollView *)smoothView;

/// collectionview
/// @param scrollView scrollView description
/// @param decelerate decelerate description
- (void)smoothViewCollectionViewDidEndDragging:(ULSmoothScrollView *)smoothView
                                    scrollView:(UIScrollView *)scrollView
                                willDecelerate:(BOOL)decelerate;

- (void)smoothViewCollectionViewDidEndScrollingAnimation:(ULSmoothScrollView *)smoothView
                                              scrollView:(UIScrollView *)scrollView;

- (void)smoothViewAfterInitSetScrollViewOffsetAndInset:(ULSmoothScrollView *)smoothView;

// 滑动停止 元素上报
- (void)smoothViewDidEndDecelerating:(ULSmoothScrollView *)smoothView;

@end

@interface ULSmoothScrollView : UIView

@property (nonatomic, weak) id<ULSmoothScrollViewDelegate> delegate;
@property (nonatomic, weak) id<ULSmoothScrollViewDataSource> dataSource;

// 当前已经加载过的可用的列表字典，key是index值，value是对应列表
@property (nonatomic, strong, readonly) NSDictionary *listDict;
/// 吸顶临界高度（默认为0）
@property (nonatomic, assign) CGFloat ceilPointHeight;
/// 底部漏出内容高度
@property (nonatomic, assign) CGFloat bottomMargin;
/// 默认segment的index
@property (nonatomic, assign) NSInteger defaultSelectedIndex;
/// 当前显示的segment的index
@property (nonatomic, assign) NSInteger currentIndex;
/// 是否通过拖拽滑动到顶部
@property (nonatomic, assign, readonly) BOOL isOnTop;
@property (nonatomic, assign) ULSmoothScrollViewHoverType hoverType;

/**
 设置内部视图布局（初始化时调用）
 */
- (void)setupViews;
/**
 刷新数据
 */
- (void)reloadData;
/**
 点击segment时手动置顶
 */
- (void)showingOnTop;
/**
 上拉刷新数据时，更新scrollview的contentsize;
 刷新详情头部数据时，更新scrollview的contentsize
 此更新不涉及segment栏数量（listDict的数据源）的变化
 */
- (void)refreshTopScrollViewContentHeight;
/**
 更新头部视图数据、底部视图数据、listDict数据源（segment数量可变化，滑动的第一个index）；
 比如如广播剧切季
 */
- (void)refreshHeaderSegemntAndListDict;

/**
 点击segment时滑动至指定index
 @param index index
 @param animation animation
 */
- (void)scrollHorizentalToIndex:(NSInteger)index animation:(BOOL)animation;
/**
 返回TopScrollView
 */
- (UIScrollView *)getTopScrollView;
/**
 返回TopScrollViewContenOffSetY
 */
- (CGFloat)getTopScrollViewContentOffectY;

- (void)dragDismissWithoutAnimation;

- (void)scrollToOriginalPoint;

/// 屏幕旋转更新UI
- (void)refreshUIForRotationWithFrame:(CGRect)frame bottomMargin:(CGFloat)bottomMargin;

@end

NS_ASSUME_NONNULL_END
