//
//  ULSmoothContainerView.m
//  KilaKit
//
//  Created by 方世峰 on 2021/5/11.
//  Copyright © 2021 LeeWong. All rights reserved.
//

#import "ULSmoothContainerView.h"
#import "ULSmoothContainnerListViewDelegate.h"
#import "Masonry.h"
#import "UIView+UL.h"
#import "ULBaseFunction.h"

@interface ULSmoothContainerView ()<UICollectionViewDelegate, UICollectionViewDataSource>

@property (nonatomic, strong) UICollectionView *horizentalCollectView;
@property (nonatomic, strong) NSMutableArray *tableViewSources;
@property (nonatomic, strong) UIView *segmentHeader;
@property (nonatomic, assign) NSInteger dataCount;
@property (nonatomic, strong) NSMutableDictionary *observeListDict;
@property (nonatomic, strong) NSDictionary *listDict;
@property (nonatomic, assign) CGFloat containerTopMargin;

@end

@implementation ULSmoothContainerView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.horizentalCollectView];
        [self addSubview:self.segmentHeader];
        self.tableViewSources = [[NSMutableArray alloc] init];
        self.observeListDict = [[NSMutableDictionary alloc] init];
        self.currentListIndex = 0;
    }
    return self;
}

#pragma mark - Public
- (UIScrollView *)getCurrentListScrollView {
    id <ULSmoothContainnerListViewDelegate> list = [self.tableViewSources objectAtIndex:self.currentListIndex];
    return list.listScrollView;
}

- (void)scrollContainerToIndex:(NSInteger)index animation:(BOOL)animation {
    if (self.tableViewSources.count > index) {
        [self.horizentalCollectView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:animation];
        self.currentListIndex = index;
    }
}

- (void)setupContainerSegmentView:(UIView *)segmentView listView:(NSDictionary *)listDict topMargin:(CGFloat)margin {
    [self.tableViewSources removeAllObjects];
    self.containerTopMargin = margin;
    self.horizentalCollectView.frame = CGRectMake(0, margin, self.ul_width, self.ul_height - margin);
    self.segmentHeader.frame = segmentView.bounds;
    [self.segmentHeader addSubview:segmentView];
    [segmentView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(0);
    }];
    [self.segmentHeader mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.right.left.top.equalTo(0);
        make.height.equalTo(segmentView.frame.size.height);
    }];

    for (int i = 0; i < listDict.allValues.count; i++) {
        id <ULSmoothContainnerListViewDelegate> list = listDict[@(i)];
        [self.tableViewSources addObject:list];
        list.listView.frame = CGRectMake(0, 0,
                                         CGRectGetWidth(self.horizentalCollectView.bounds),
                                         CGRectGetHeight(self.horizentalCollectView.bounds));
    }

    [self.horizentalCollectView reloadData];
}

- (void)updateContainerListScrollOffset:(CGPoint)offset {
    id <ULSmoothContainnerListViewDelegate> list = [self.tableViewSources objectAtIndex:self.currentListIndex];
    [list.listScrollView setContentOffset:offset];
}

- (void)disableContentScroll {
    for (id <ULSmoothContainnerListViewDelegate> list in self.tableViewSources) {
        list.listScrollView.scrollEnabled = NO;
    }
}

- (void)enableContentScroll {
    for (id <ULSmoothContainnerListViewDelegate> list in self.tableViewSources) {
        list.listScrollView.scrollEnabled = YES;
    }
}

- (void)forbidContentScroll {
    for (id <ULSmoothContainnerListViewDelegate> list in self.tableViewSources) {
        [list.listScrollView setContentOffset:CGPointZero animated:NO];
    }
}

- (void)resetAllContentScrollViewOffSet {
    for (id <ULSmoothContainnerListViewDelegate> list in self.tableViewSources) {
        list.listScrollView.scrollEnabled = NO;
        [list.listScrollView setContentOffset:CGPointZero animated:NO];
    }
}

// 屏幕旋转刷新UI
- (void)refreshUIForRotationWithContainerSize:(CGSize)size {
    self.ul_width = size.width;
    self.ul_height = size.height;
    [self ul_bezierPathTopCornerWithCornerRadii:9.f];
    self.horizentalCollectView.ul_width = size.width;
    self.horizentalCollectView.ul_height = size.height - self.containerTopMargin;
    [self.horizentalCollectView reloadData];
    // 刷新偏移量
    [self scrollContainerToIndex:self.currentListIndex animation:NO];
}

- (UICollectionView *)horizentalCollectView {
    if (!_horizentalCollectView) {
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;
        _horizentalCollectView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _horizentalCollectView.dataSource = self;
        _horizentalCollectView.delegate = self;
        _horizentalCollectView.pagingEnabled = YES;
        _horizentalCollectView.bounces = NO;
        _horizentalCollectView.showsHorizontalScrollIndicator = NO;
        _horizentalCollectView.scrollsToTop = NO;
        [_horizentalCollectView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"Cell"];

        if (@available(iOS 11.0, *)) {
            _horizentalCollectView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        if (@available(iOS 10.0, *)) {
            _horizentalCollectView.prefetchingEnabled = NO;
        }
    }
    return _horizentalCollectView;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.tableViewSources.count;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    id <ULSmoothContainnerListViewDelegate>list = [self.tableViewSources objectAtIndex:indexPath.item];
    if (list.listView != nil && list.listView.superview != cell.contentView) {
        for (UIView *view in cell.contentView.subviews) {
            [view removeFromSuperview];
        }
    }

    [cell.contentView addSubview:list.listView];
    list.listView.frame = CGRectMake(0, 0,
                                     CGRectGetWidth(self.horizentalCollectView.bounds),
                                     CGRectGetHeight(self.horizentalCollectView.bounds));

    return cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView  {

    if (scrollView == self.horizentalCollectView) {
        NSInteger index = getDefaultDivisionValue(scrollView.contentOffset.x, scrollView.bounds.size.width);
        NSInteger ratio = getSafeMode((int)scrollView.contentOffset.x, (int)scrollView.bounds.size.width);
        if (self.delegate && [self.delegate respondsToSelector:@selector(ulSmoothContainerView:collectViewDidScroll:)]) {
            [self.delegate ulSmoothContainerView:self collectViewDidScroll:scrollView];
        }
        if (index != self.currentListIndex && ratio == 0) {
            self.currentListIndex = index;
            if (self.delegate && [self.delegate respondsToSelector:@selector(ulSmoothContainerView:collectViewDidScroll:toIndex:)]) {
                [self.delegate ulSmoothContainerView:self collectViewDidScroll:scrollView toIndex:index];
            }
        }
    } else {
        NSLog(@"tableContainerOffSetY:%f", scrollView.contentOffset.y);

    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (self.delegate && [self.delegate respondsToSelector:@selector(ulSmoothContainerView:scrollViewDidEndDecelerating:)]) {
        [self.delegate ulSmoothContainerView:self scrollViewDidEndDecelerating:scrollView];
    }
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    if (self.delegate && [self.delegate respondsToSelector:@selector(ulSmoothContainerView:scrollViewDidEndScrollingAnimation:)]) {
        [self.delegate ulSmoothContainerView:self scrollViewDidEndScrollingAnimation:scrollView];
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(self.ul_width, self.ul_height - self.containerTopMargin);
}

#pragma mark - Initialize
- (UIView *)segmentHeader {
    if (!_segmentHeader) {
        _segmentHeader = [[UIView alloc] initWithFrame:CGRectZero];
        _segmentHeader.backgroundColor = [UIColor whiteColor];
    }
    return _segmentHeader;
}

@end
