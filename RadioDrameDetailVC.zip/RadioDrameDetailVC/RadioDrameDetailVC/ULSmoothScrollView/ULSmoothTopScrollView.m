//
//  ULSmoothTopScrollView.m
//  KilaKit
//
//  Created by 方世峰 on 2021/5/11.
//  Copyright © 2021 LeeWong. All rights reserved.
//

#import "ULSmoothTopScrollView.h"

@interface ULSmoothTopScrollView ()<UIGestureRecognizerDelegate>

@end

@implementation ULSmoothTopScrollView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *view = [super hitTest:point withEvent:event];
    if ([view isKindOfClass:[UIScrollView class]]) {
        return nil;
    }
    return view;
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizerShouldBegin:(UIPanGestureRecognizer *)gestureRecognizer {
    CGPoint translation = [gestureRecognizer translationInView:gestureRecognizer.view];
    if (translation.x != 0) {
        return NO;
    } else {
        return YES;
    }
}


@end
