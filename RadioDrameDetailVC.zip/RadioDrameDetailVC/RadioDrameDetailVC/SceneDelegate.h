//
//  SceneDelegate.h
//  RadioDrameDetailVC
//
//  Created by 郭朝顺 on 2024/6/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

