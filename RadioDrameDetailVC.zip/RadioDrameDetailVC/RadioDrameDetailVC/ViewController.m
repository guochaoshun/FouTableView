//
//  ViewController.m
//  RadioDrameDetailVC
//
//  Created by 郭朝顺 on 2024/6/21.
//

#import "ViewController.h"
#import "ULSmoothScrollView.h"
#import "ULChapterListViewController.h"
#import "Masonry.h"

@interface ViewController ()<ULSmoothScrollViewDelegate, ULSmoothScrollViewDataSource>

@property (nonatomic, strong) ULSmoothScrollView *smoothView;

@property (nonatomic, strong) UIView *detailHeaderView;

@property (nonatomic, strong) UIView *hoverTitleView;


@property (nonatomic, strong) ULChapterListViewController *chapter1;
@property (nonatomic, strong) ULChapterListViewController *chapter2;
@property (nonatomic, strong) ULChapterListViewController *chapter3;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    

    ULSmoothScrollView *smoothView = [[ULSmoothScrollView alloc] initWithFrame:CGRectMake(0, 64, 100, 100)];
    smoothView.backgroundColor = UIColor.cyanColor;
    smoothView.clipsToBounds = YES;
    smoothView.delegate = self;
    smoothView.dataSource = self;
    smoothView.ceilPointHeight = 0;
    smoothView.bottomMargin = 120;


    [self.view addSubview:smoothView];

    self.smoothView = smoothView;

    [smoothView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(64);
        make.left.right.bottom.equalTo(0);
    }];

    [smoothView layoutIfNeeded];

    if (self.chapter1 == nil) {
        ULChapterListViewController *chapterList = [[ULChapterListViewController alloc] init];
        chapterList.tableCount = 50;
        chapterList.tableID = @"1";
        self.chapter1 = chapterList;
    }

    if (self.chapter2 == nil) {
        ULChapterListViewController *chapterList = [[ULChapterListViewController alloc] init];
        chapterList.tableCount = 10;
        chapterList.tableID = @"2";
        self.chapter2 = chapterList;
    }

    if (self.chapter3 == nil) {
        ULChapterListViewController *chapterList = [[ULChapterListViewController alloc] init];
        chapterList.tableCount = 100;
        chapterList.tableID = @"3";
        self.chapter3 = chapterList;
    }



    [smoothView setupViews];
    [smoothView reloadData];

}


#pragma mark - ULSmoothScrollViewDataSource
- (UIView *)headerViewInSmoothView:(ULSmoothScrollView *)smoothView {
    return self.detailHeaderView;
}

- (UIView *)segmentedViewInSmoothView:(ULSmoothScrollView *)smoothView {
    return self.hoverTitleView;
}

- (NSInteger)numberOfListsInSmoothView:(ULSmoothScrollView *)smoothView {
    return 3;
}

- (id<ULSmoothContainnerListViewDelegate>)smoothView:(ULSmoothScrollView *)smoothView initListAtIndex:(NSInteger)index {
    if (index == 0) {

        return self.chapter1;
    } else if (index == 1) {
        return self.chapter2;
    } else if (index == 2) {
        return self.chapter3;
    }
    return nil;
}


- (void)smoothView:(ULSmoothScrollView *)smoothView listScrollViewDidScroll:(UIScrollView *)scrollView contentOffset:(CGPoint)contentOffset {
}

- (void)smoothViewDragEnded:(ULSmoothScrollView *)smoothView isOnTop:(BOOL)isOnTop {
}

- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidScroll:(UIScrollView *)scrollView {

}

- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidEndScroll:(UIScrollView *)scrollView {
}

- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidEndDecelerating:(UIScrollView *)scrollView {

}

- (void)smoothView:(ULSmoothScrollView *)smoothView scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {

}


- (UIView *)detailHeaderView {
    if (_detailHeaderView == nil) {
        _detailHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 400, 1000)];
        _detailHeaderView.backgroundColor = UIColor.orangeColor;
        for (int i = 0; i < 10; i++) {
            UILabel *red = [[UILabel alloc] initWithFrame:CGRectMake(0, i * 100, 400, 80)];
            red.text = @"详情区";
            red.backgroundColor = UIColor.redColor;
            [_detailHeaderView addSubview:red];
        }

    }
    return _detailHeaderView;
}

- (UIView *)hoverTitleView {
    if (_hoverTitleView == nil) {
        _hoverTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 400, 80)];
        _hoverTitleView.backgroundColor = UIColor.grayColor;
        for (int i = 0; i < 3; i++) {
            UILabel *green = [[UILabel alloc] initWithFrame:CGRectMake(i*100, 10, 80, 50)];
            green.text = [NSString stringWithFormat:@"tab_%d",i];
            green.backgroundColor = UIColor.greenColor;
            [_hoverTitleView addSubview:green];
        }

    }
    return _hoverTitleView;
}

@end
