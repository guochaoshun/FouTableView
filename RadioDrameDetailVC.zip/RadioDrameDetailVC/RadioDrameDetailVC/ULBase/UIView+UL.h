//
//  UIView+UL.h
//  UXLive
//
//  Created by codychen on 2018/1/4.
//  Copyright © 2018年 UXIN CO. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (UL)

@property (nonatomic) CGFloat ul_left;        ///< Shortcut for frame.origin.x.
@property (nonatomic) CGFloat ul_top;         ///< Shortcut for frame.origin.y
@property (nonatomic) CGFloat ul_right;       ///< Shortcut for frame.origin.x + frame.size.width
@property (nonatomic) CGFloat ul_bottom;      ///< Shortcut for frame.origin.y + frame.size.height
@property (nonatomic) CGFloat ul_width;       ///< Shortcut for frame.size.width.
@property (nonatomic) CGFloat ul_height;      ///< Shortcut for frame.size.height.
@property (nonatomic) CGFloat ul_centerX;     ///< Shortcut for center.x
@property (nonatomic) CGFloat ul_centerY;     ///< Shortcut for center.y
@property (nonatomic) CGPoint ul_origin;      ///< Shortcut for frame.origin.
@property (nonatomic) CGSize  ul_size;        ///< Shortcut for frame.size.

//为UIView扩展一个方法，用于响应事件链
- (UIViewController *)queryBestAndLastedViewControllerResponder;

- (void)removeSubviews;

+ (nullable UIViewController *)getCurrentVC;

/**
 *  动态添加手势
 */
- (void)setTapActionWithBlock:(void (^)(void))block;

- (void)setLongPressActionWithBlock:(void (^)(UIGestureRecognizer *gesture))block;

/**
 获取当前视图相对于window的绝对位置

 @return frame
 */
- (CGRect)ul_rectForWindow;

/**
 获取当前视图相对于view的绝对位置 如果view==nil 则返回相对于keyWindow的位置

 @param view 相对的view
 @return frame
 */
- (CGRect)ul_rectForView:(UIView *)view;

/**
 设置边框
 
 @param rectCorners 圆角位置
 @param cornerRadii 圆角值 如果未切圆角传0即可
 @param borderWidth 边框宽度
 @param borderColor 边框颜色
 */
- (void)ul_borderWithRectCorners:(UIRectCorner)rectCorners
                               cornerRadii:(CGFloat)cornerRadii
                               borderWidth:(CGFloat)borderWidth
                               borderColor:(UIColor *)borderColor;

/**
 设置圆角  需要在调用此方法之前调用 [layoutIfNeeded] 获取frame

 @param button button
 @param rectCorner  UIRectCorner
 UIRectCornerTopRight
 UIRectCornerBottomLeft
 UIRectCornerBottomRight
 */
- (void)ul_bezierPathCornerWithRectCorners:(UIRectCorner)rectCorners cornerRadii:(CGFloat)cornerRadii;

/**
 设置左上及右上圆角 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 */
- (void)ul_bezierPathTopCornerWithCornerRadii:(CGFloat)cornerRadii;
/**
 设置左下及右下圆角 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 */
- (void)ul_bezierPathBottomCornerWithCornerRadii:(CGFloat)cornerRadii;
/**
 设置左上及左下圆角 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 */
- (void)ul_bezierPathLeftCornerWithCornerRadii:(CGFloat)cornerRadii;
/**
 设置右上及右下圆角 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 */
- (void)ul_bezierPathRightCornerWithCornerRadii:(CGFloat)cornerRadii;

/**
 设置所有圆角 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 */
- (void)ul_bezierPathAllCornerWithCornerRadii:(CGFloat)cornerRadii;

/**
 设置圆角和边框  需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 
 @param button button
 @param rectCorner  UIRectCorner
 UIRectCornerTopRight
 UIRectCornerBottomLeft
 UIRectCornerBottomRight
 */
- (void)ul_cornerAndBorderWithRectCorners:(UIRectCorner)rectCorners
                                        cornerRadii:(CGFloat)cornerRadii
                                        borderWidth:(CGFloat)borderWidth
                                        borderColor:(UIColor *)borderColor;

/**
 设置左上及右上圆角和边框 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame

 @param cornerRadii 圆角值
 @param borderWidth 边框大小
 @param borderColor 边框颜色
 */
- (void)ul_topCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                           borderWidth:(CGFloat)borderWidth
                                           borderColor:(nullable UIColor *)borderColor;

/**
 设置左下及右下圆角和边框 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 
 @param cornerRadii 圆角值
 @param borderWidth 边框大小
 @param borderColor 边框颜色
 */
- (void)ul_bottomCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                              borderWidth:(CGFloat)borderWidth
                                              borderColor:(UIColor *)borderColor;

/**
 设置左上及左下圆角和边框 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 
 @param cornerRadii 圆角值
 @param borderWidth 边框大小
 @param borderColor 边框颜色
 */
- (void)ul_leftCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                     borderWidth:(CGFloat)borderWidth
                                     borderColor:(UIColor *)borderColor;

/**
 设置右上及右下圆角和边框 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 
 @param cornerRadii 圆角值
 @param borderWidth 边框大小
 @param borderColor 边框颜色
 */
- (void)ul_rightCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                             borderWidth:(CGFloat)borderWidth
                                             borderColor:(UIColor *)borderColor;

/**
 设置所有圆角和边框 需要在调用此方法之前调用 [layoutIfNeeded] 获取frame
 */
- (void)ul_allCornerAndBoWithCornerRadii:(CGFloat)cornerRadii
                                       borderWidth:(CGFloat)borderWidth
                                       borderColor:(nullable UIColor *)borderColor;

/**
 给view添加一个分割线

 @param aTop aTop description
 @param lineColor lineColor description
 @return return value description
 */
- (UIView *)ul_addSeperateLineAtTop:(BOOL)aTop lineColor:(UIColor *)lineColor;

/**
 
 删除边框  注意：需保证subLayers的第一个是边框的layer
 如果需要用到remove 加边框方法建议使用 ul_bezierPathBorderWithRectCorners方法，不建议使用同时设置圆角和边框。
 */
- (void)removeBorder;


- (BOOL)isDisplayedInScreen;

@end

NS_ASSUME_NONNULL_END
