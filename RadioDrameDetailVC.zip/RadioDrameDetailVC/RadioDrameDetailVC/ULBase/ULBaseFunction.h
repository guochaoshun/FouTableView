//
//  ULBaseFunction.h
//  Pods
//
//  Created by liuyang on 2023/11/7.
//

#ifndef ULBaseFunction_h
#define ULBaseFunction_h

#import <Foundation/Foundation.h>

/**
 *  指定随机数范围[from,to]包括from，包括to
 *
 *  @param from 从这个开始(包含)
 *  @param to   到这个结束(包含)
 *
 *  @return 结果
 */
static inline NSInteger randomNumberRange(NSInteger from, NSInteger to) {

    return (NSInteger)(from + (arc4random() % ((to - from) + 1)));
}

/**
 除法运算默认方法,用于避免分母为0的情况,导致的app crash
 @param molecule 分子
 @param denominator 分母
 @param defaultValue 默认值
 @return 除数值
 */
static inline CGFloat getDivisionValue(CGFloat molecule, CGFloat denominator, CGFloat defaultValue) {
    if (denominator == 0 || isnan(denominator) || isinf(denominator)) {
        return defaultValue;
    }
    CGFloat value = molecule / denominator;
    return value;
}

/**
 除法 默认值为0
 */
static inline CGFloat getDefaultDivisionValue(CGFloat value, CGFloat denominator) {
    return getDivisionValue(value, denominator, 0);
}


/**
 安全取余，用于避免分母为0的情况,导致的app crash
 @param dividend 分子
 @param divisor 分母
 @return 余数
 */
static inline NSInteger getSafeMode(NSInteger dividend, NSInteger divisor) {
    NSInteger mod = 0;
    if (divisor != 0 ) {
        mod = dividend % divisor;
    }
    return mod;
}

/**
 对随机数安全取余，用于避免分母为0的情况,导致的app crash
 @param dividend 分子
 @param divisor 分母
 @return 余数
 */
static inline NSInteger getSafeModeArc4random(NSInteger divisor) {
    NSInteger mod = 0;
    if (divisor != 0 ) {
        mod = arc4random() % divisor;
    }
    return mod;
}

#endif /* ULBaseFunction_h */
