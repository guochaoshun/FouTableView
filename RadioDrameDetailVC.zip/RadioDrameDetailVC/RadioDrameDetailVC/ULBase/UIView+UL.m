//
//  UIView+UL.m
//  UXLive
//
//  Created by codychen on 2018/1/4.
//  Copyright © 2018年 UXIN CO. All rights reserved.
//

#import "UIView+UL.h"
#import <objc/runtime.h>

static const char *ULActionHandlerTapGestureKey;
static const char *ULActionHandlerLongPressGestureKey;
static NSString *kULUIViewCategoryLayerKey = @"UIViewCategoryLayerKey";

@implementation UIView (UL)

- (CGFloat)ul_left {
    return self.frame.origin.x;
}

- (void)setUl_left:(CGFloat)x {
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)ul_top {
    return self.frame.origin.y;
}

- (void)setUl_top:(CGFloat)y {
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)ul_right {
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setUl_right:(CGFloat)right {
    CGRect frame = self.frame;
    frame.origin.x = right - frame.size.width;
    self.frame = frame;
}

- (CGFloat)ul_bottom {
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setUl_bottom:(CGFloat)bottom {
    CGRect frame = self.frame;
    frame.origin.y = bottom - frame.size.height;
    self.frame = frame;
}

- (CGFloat)ul_width {
    return self.frame.size.width;
}

- (void)setUl_width:(CGFloat)width {
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)ul_height {
    return self.frame.size.height;
}

- (void)setUl_height:(CGFloat)height {
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

- (CGFloat)ul_centerX {
    return self.center.x;
}

- (void)setUl_centerX:(CGFloat)centerX {
    self.center = CGPointMake(centerX, self.center.y);
}

- (CGFloat)ul_centerY {
    return self.center.y;
}

- (void)setUl_centerY:(CGFloat)centerY {
    self.center = CGPointMake(self.center.x, centerY);
}

- (CGPoint)ul_origin {
    return self.frame.origin;
}

- (void)setUl_origin:(CGPoint)origin {
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

- (CGSize)ul_size {
    return self.frame.size;
}

- (void)setUl_size:(CGSize)size {
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}


//为UIView扩展一个方法，用于响应事件链
- (UIViewController *)queryBestAndLastedViewControllerResponder {

    UIResponder *nexRes=[self nextResponder];
    do {
        //判读当前的响应者是否UIViewController
        if ([nexRes isKindOfClass:[UIViewController class]]) {
            //是否直接处理
            return  (UIViewController*)nexRes;
        } else {
            //否则继续寻找
            nexRes=[nexRes nextResponder];
        }
    } while (nexRes!=nil);
    return nil;
}


/**
 *  动态添加手势
 */

- (void)setTapActionWithBlock:(void (^)(void))block {
    
    self.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *gesture = objc_getAssociatedObject(self, &ULActionHandlerTapGestureKey);
    
    if (!gesture) {
        gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleActionForTapGesture:)];
        [self addGestureRecognizer:gesture];
        objc_setAssociatedObject(self, &ULActionHandlerTapGestureKey, gesture, OBJC_ASSOCIATION_RETAIN);
    }
    
    objc_setAssociatedObject(self, &ULActionHandlerTapGestureKey, block, OBJC_ASSOCIATION_COPY);
}

- (void)handleActionForTapGesture:(UITapGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateRecognized)  {
        void(^action)(void) = objc_getAssociatedObject(self, &ULActionHandlerTapGestureKey);
        if (action)  {
            action();
        }
    }
}

- (void)setLongPressActionWithBlock:(void (^)(UIGestureRecognizer *gesture))block {
    
    self.userInteractionEnabled = YES;
    
    UILongPressGestureRecognizer *gesture = objc_getAssociatedObject(self, &ULActionHandlerLongPressGestureKey);
    if (!gesture) {
        gesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleActionForLongPressGesture:)];
        [self addGestureRecognizer:gesture];
        objc_setAssociatedObject(self, &ULActionHandlerLongPressGestureKey, gesture, OBJC_ASSOCIATION_RETAIN);
    }
    
    objc_setAssociatedObject(self, &ULActionHandlerLongPressGestureKey, block, OBJC_ASSOCIATION_COPY);
}

- (void)handleActionForLongPressGesture:(UITapGestureRecognizer *)gesture {
    void(^action)(UIGestureRecognizer *gesture) = objc_getAssociatedObject(self, &ULActionHandlerLongPressGestureKey);
    if (action)  {
        action(gesture);
    }
}




- (void)ul_bezierPathCornerWithRectCorners:(UIRectCorner)rectCorners cornerRadii:(CGFloat)cornerRadii  {
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:rectCorners cornerRadii:CGSizeMake(cornerRadii, cornerRadii)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    maskLayer.path = path.CGPath;
    self.layer.mask = maskLayer;
}

- (void)ul_bezierPathTopCornerWithCornerRadii:(CGFloat)cornerRadii  {
    [self ul_bezierPathCornerWithRectCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:cornerRadii];
}

- (void)ul_bezierPathBottomCornerWithCornerRadii:(CGFloat)cornerRadii  {
    [self ul_bezierPathCornerWithRectCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:cornerRadii];
}

- (void)ul_bezierPathLeftCornerWithCornerRadii:(CGFloat)cornerRadii  {
    [self ul_bezierPathCornerWithRectCorners:UIRectCornerTopLeft | UIRectCornerBottomLeft cornerRadii:cornerRadii];
}

- (void)ul_bezierPathRightCornerWithCornerRadii:(CGFloat)cornerRadii  {
    [self ul_bezierPathCornerWithRectCorners:UIRectCornerTopRight | UIRectCornerBottomRight cornerRadii:cornerRadii];
}

- (void)ul_bezierPathAllCornerWithCornerRadii:(CGFloat)cornerRadii {
    [self ul_bezierPathCornerWithRectCorners:UIRectCornerAllCorners cornerRadii:cornerRadii];
}

- (void)ul_borderWithRectCorners:(UIRectCorner)rectCorners cornerRadii:(CGFloat)cornerRadii borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor {

    //如果已经添加过边框直接return
    for (CALayer *layer in self.layer.sublayers) {
        if ([[layer valueForKey:kULUIViewCategoryLayerKey] isEqual:@(YES)]) {
            return;
        }
    }
    //边框
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:rectCorners cornerRadii:CGSizeMake(cornerRadii, cornerRadii)];
    CAShapeLayer *borderLayer = [CAShapeLayer layer];
    [borderLayer setValue:@(YES) forKey:kULUIViewCategoryLayerKey];
    borderLayer.path = path.CGPath;
    borderLayer.fillColor = [UIColor clearColor].CGColor;
    borderLayer.strokeColor = borderColor.CGColor;
    borderLayer.lineWidth = borderWidth;
    borderLayer.frame = self.bounds;
    [self.layer addSublayer:borderLayer];
}

- (void)ul_cornerAndBorderWithRectCorners:(UIRectCorner)rectCorners
                                        cornerRadii:(CGFloat)cornerRadii
                                        borderWidth:(CGFloat)borderWidth
                                        borderColor:(UIColor *)borderColor {
    [self ul_bezierPathCornerWithRectCorners:rectCorners cornerRadii:cornerRadii];
    [self ul_borderWithRectCorners:rectCorners cornerRadii:cornerRadii borderWidth:borderWidth borderColor:borderColor];
    
}

- (void)ul_topCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                           borderWidth:(CGFloat)borderWidth
                                           borderColor:(UIColor *)borderColor {
    [self ul_cornerAndBorderWithRectCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:cornerRadii borderWidth:borderWidth borderColor:borderColor];
}

- (void)ul_bottomCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                              borderWidth:(CGFloat)borderWidth
                                              borderColor:(UIColor *)borderColor {
    [self ul_cornerAndBorderWithRectCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:cornerRadii borderWidth:borderWidth borderColor:borderColor];
}

- (void)ul_leftCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                            borderWidth:(CGFloat)borderWidth
                                            borderColor:(UIColor *)borderColor {
    [self ul_cornerAndBorderWithRectCorners:UIRectCornerTopLeft | UIRectCornerBottomLeft cornerRadii:cornerRadii borderWidth:borderWidth borderColor:borderColor];
}

- (void)ul_rightCornerAndBorderWithCornerRadii:(CGFloat)cornerRadii
                                             borderWidth:(CGFloat)borderWidth
                                             borderColor:(UIColor *)borderColor {
    [self ul_cornerAndBorderWithRectCorners:UIRectCornerTopRight | UIRectCornerBottomRight cornerRadii:cornerRadii borderWidth:borderWidth borderColor:borderColor];
}

- (void)ul_allCornerAndBoWithCornerRadii:(CGFloat)cornerRadii
                                       borderWidth:(CGFloat)borderWidth
                                       borderColor:(UIColor *)borderColor {
    [self ul_cornerAndBorderWithRectCorners:UIRectCornerAllCorners cornerRadii:cornerRadii borderWidth:borderWidth borderColor:borderColor];
}


- (void)removeBorder {
    for (CALayer *layer in self.layer.sublayers) {
        if ([[layer valueForKey:kULUIViewCategoryLayerKey] isEqual:@(YES)]) {
            [layer removeFromSuperlayer];
        }
    }
}

- (BOOL)isDisplayedInScreen {
    if (self == nil) {
        return FALSE;
    }

    CGRect screenRect = [UIScreen mainScreen].bounds;

    // 转换view对应window的Rect
    CGRect rect = [self ul_rectForWindow];
    if (CGRectIsEmpty(rect) || CGRectIsNull(rect)) {
        return FALSE;
    }

    // 若view 隐藏
    if (self.hidden) {
        return FALSE;
    }

    // 若没有superview
    if (self.superview == nil) {
        return FALSE;
    }

    // 若size为CGrectZero
    if (CGSizeEqualToSize(rect.size, CGSizeZero)) {
        return  FALSE;
    }

    // 获取 该view与window 交叉的 Rect
    CGRect intersectionRect = CGRectIntersection(rect, screenRect);
    if (CGRectIsEmpty(intersectionRect) || CGRectIsNull(intersectionRect)) {
        return FALSE;
    }

    return TRUE;
}

@end
