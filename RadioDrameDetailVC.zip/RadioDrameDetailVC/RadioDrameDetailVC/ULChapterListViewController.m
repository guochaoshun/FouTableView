//
//  ULChapterListViewController.m
//  RadioDrameDetailVC
//
//  Created by 郭朝顺 on 2024/6/21.
//

#import "ULChapterListViewController.h"
#import "Masonry.h"

@interface ULChapterListViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@end

@implementation ULChapterListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableID = @"";
    self.view.backgroundColor = [UIColor whiteColor]; // 设置视图背景颜色
}


- (void)setTableCount:(NSInteger)tableCount {
    _tableCount = tableCount;
    [self.tableView reloadData];
}

#pragma mark - UITableViewDataSource Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableCount; // 示例数据，返回20行
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.backgroundColor = UIColor.brownColor;
    cell.textLabel.text = [NSString stringWithFormat:@"Row %@ - %zd", self.tableID, indexPath.row];
    return cell;
}



/// 返回listView，如果是vc就返回vc.view,如果是自定义view，就返回view本身
- (UIView *)listView {
    return self.tableView;
}

/// 返回vc或view内部持有的UIScrollView或UITableView或UICollectionView
- (UIScrollView *)listScrollView {
    return self.tableView;
}
/// 返回vc或view内部持有的UIScrollView或UITableView或UICollectionView的内容总高度
- (CGFloat)listScrollViewContentHeight {
    return self.tableCount * 44;
}


- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}


@end
