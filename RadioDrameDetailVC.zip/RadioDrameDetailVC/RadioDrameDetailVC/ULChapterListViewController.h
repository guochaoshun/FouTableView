//
//  ULChapterListViewController.h
//  RadioDrameDetailVC
//
//  Created by 郭朝顺 on 2024/6/21.
//

#import <UIKit/UIKit.h>
#import "ULSmoothContainnerListViewDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface ULChapterListViewController : UIViewController<ULSmoothContainnerListViewDelegate>

@property (nonatomic, assign) NSInteger tableCount;

@property (nonatomic, copy) NSString *tableID;

@end

NS_ASSUME_NONNULL_END
